
<style>
    ul{
        list-style:none;

    }
    ul li{
        background-color:black;
        width:200px;
        padding:15px;
        position:relative;
        border-right:1px solid white;
    }

    ul li ul{
        left:100%;
        top:-2%;
        position:absolute;
        display:none;
        
    }
    ul li ul li{
        text-align:center;
        border-top:1px solid gray;
    }
    ul li ul li:hover{
        background-color:#A9A9A9;
    }
    ul li:hover ul{
        display:block;

    }
    
</style>
<div class="container">
    <h1>SPACE CHECKERS!!</h1>
    <br/>

        <ul>
            <li><i class="small material-icons">credit_card</i> CHECKERS CC 
                <ul>
                    <li><a href="?pg=checkers&opt=card">CC [+][+]</a></li>
                </ul>
            </li>
            <li> <i class="small material-icons">person</i> CHECKERS LOGIN 
                <ul>
                    <li> <a href="?pg=checkers&opt=login">Steam</a> </li>
                    <li><a href="?pg=checkers&opt=login">League of Legends</a></li>
                    <li><a href="?pg=checkers&opt=login">Red Tube</a></li>
                </ul>
            </li>
        </ul>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officiis distinctio, laboriosam quas provident possimus rem id iure ipsum nulla repellat sed architecto cumque eos? Consequatur necessitatibus accusamus officia distinctio sint.
    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Fugiat aut harum sed deleniti qui autem iste tempore ipsa repellat velit unde, inventore sit quos natus libero officiis nulla aperiam vero?
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Praesentium nostrum blanditiis totam sapiente quis qui enim doloremque. Facere delectus odit necessitatibus quia mollitia sed cum distinctio, deleniti nostrum tempora molestiae.
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Nesciunt odio incidunt soluta vitae. Laboriosam voluptatum sequi aliquam quas deleniti soluta officia praesentium aperiam, repellat excepturi incidunt doloribus molestias enim consequatur.lorem
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Illum dignissimos reiciendis error at voluptatibus recusandae vitae labore in. Consequuntur illum adipisci velit excepturi totam quibusdam vitae quasi dicta quo tempore.
    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ea est quidem, necessitatibus, laboriosam quibusdam fugit quis provident explicabo dolores ipsa quasi laborum quae temporibus magni corporis rem excepturi alias blanditiis.
</div>