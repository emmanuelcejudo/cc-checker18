<h1>Cadastre-se</h1>
<form action="?pot=login" method="post">
    nome: <input type="text" name="nome" id="">
    senha: <input type="password" name="senha" id="">
    email: <input type="email" name="email" id="">
    <input type="submit" value="submit">
</form>