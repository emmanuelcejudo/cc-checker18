<div class="container">
    <h1> Login</h1>
    <form action="?pot=login" id="login" method="post">
       nome: <input type="text" name="nome" id=""><br/>
       senha: <input type="password" name="senha" id=""><br/>
       <input type="submit" value="submit">
    </form> 
</div>