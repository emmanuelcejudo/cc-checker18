<?php
    define("VIEW",__DIR__."/app/View");
    define("VIEW_LOGADO",VIEW."/logado");
    define("VIEW_DESLOGADO",VIEW."/deslogado");
    define("DESIGN",VIEW."/tools");
    define("PROC",__DIR__."/app/proc");